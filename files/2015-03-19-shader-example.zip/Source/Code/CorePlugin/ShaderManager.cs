﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;
using Duality.Components.Renderers;

namespace Duality_
{
	[Serializable]
    [RequiredComponent(typeof(SpriteRenderer))]
    public class ShaderManager : Component, ICmpInitializable, ICmpUpdatable
    {
        [NonSerialized]
        private SpriteRenderer _sprite;

        [NonSerialized]
        private float _value;

        void ICmpInitializable.OnInit(Component.InitContext context)
        {
            _sprite = this.GameObj.GetComponent<SpriteRenderer>();
        }

        void ICmpInitializable.OnShutdown(Component.ShutdownContext context)
        {
            // nothing to do here
        }

        void ICmpUpdatable.OnUpdate()
        {
            _value += (Time.LastDelta / 200);

            if (_value > MathF.TwoPi)
                _value -= MathF.TwoPi;

            _sprite.SharedMaterial.Res.SetUniform("red", (MathF.Sin(_value) / 2) + .5f);
        }
    }
}
