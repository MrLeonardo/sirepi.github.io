/*
 * A set of static helper classes that provide easy runtime access to the games resources.
 * This file is auto-generated. Any changes made to it are lost as soon as Duality decides
 * to regenerate it.
 */
namespace GameRes
{
	public static class Data {
		public static class Skins {
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> Button_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\Button.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> CheckButton_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\CheckButton.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> CheckGlyph_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\CheckGlyph.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> DarkPanel_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\DarkPanel.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> Form_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\Form.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> Highlight_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\Highlight.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> Panel_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\Panel.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> RadioGlyph_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\RadioGlyph.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> ScrollDown_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\ScrollDown.WidgetSkin.res"); }}
			public static Duality.ContentRef<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin> ScrollUp_WidgetSkin { get { return Duality.ContentProvider.RequestContent<SnowyPeak.Duality.Plugin.Frozen.UI.Resources.WidgetSkin>(@"Data\Skins\ScrollUp.WidgetSkin.res"); }}
			public static void LoadAll() {
				Button_WidgetSkin.MakeAvailable();
				CheckButton_WidgetSkin.MakeAvailable();
				CheckGlyph_WidgetSkin.MakeAvailable();
				DarkPanel_WidgetSkin.MakeAvailable();
				Form_WidgetSkin.MakeAvailable();
				Highlight_WidgetSkin.MakeAvailable();
				Panel_WidgetSkin.MakeAvailable();
				RadioGlyph_WidgetSkin.MakeAvailable();
				ScrollDown_WidgetSkin.MakeAvailable();
				ScrollUp_WidgetSkin.MakeAvailable();
			}
		}
		public static Duality.ContentRef<Duality.Resources.Scene> Scene_Scene { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Scene>(@"Data\Scene.Scene.res"); }}
		public static Duality.ContentRef<Duality.Resources.Material> skin_minimal_Material { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\skin_minimal.Material.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> skin_minimal_Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\skin_minimal.Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Texture> skin_minimal_Texture { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\skin_minimal.Texture.res"); }}
		public static void LoadAll() {
			Skins.LoadAll();
			Scene_Scene.MakeAvailable();
			skin_minimal_Material.MakeAvailable();
			skin_minimal_Pixmap.MakeAvailable();
			skin_minimal_Texture.MakeAvailable();
		}
	}

}
