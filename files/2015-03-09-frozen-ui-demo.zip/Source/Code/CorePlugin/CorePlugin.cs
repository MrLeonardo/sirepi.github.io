﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;
using Duality.Resources;
using SnowyPeak.Duality.Plugin.Frozen.UI.Widgets;
using OpenTK;

namespace SkinTest
{
	/// <summary>
	/// Defines a Duality core plugin.
	/// </summary>
    public class SkinTestCorePlugin : CorePlugin
    {
        private static readonly List<object> LISTBOX_DATA = new List<object>(new object[] {
            "Line 1", "Line 2", "Line 3", DateTime.Now, new Vector3(4, 5, 6), MathF.Pi,
            "Line 7", "Line 8", "Line 9", "Line 10", "Line 11", "Line 12", "Line 13", "Line 15", "Line 15"
        });

        private static readonly string LOREM_IPSUM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

		// Override methods here for global logic

        public SkinTestCorePlugin()
        {
            Scene.Entered += Scene_Entered;
        }

        void Scene_Entered(object sender, EventArgs e)
        {
            if(Scene.Current.Name == "Scene")
            {
                Scene.Current.FindComponent<SkinnedListBox>().Items = LISTBOX_DATA;
                Scene.Current.FindComponent<SkinnedTextBlock>().Text = LOREM_IPSUM;
            }
        }
    }
}
