﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;
using Duality.Components.Renderers;

namespace LoadingScreen
{
    [Serializable]
    [RequiredComponent(typeof(SpriteRenderer))]
    public class ResourcesLoader : Component, ICmpInitializable, ICmpUpdatable
    {
        private static readonly Type[] RESOURCES_TO_NOT_PRELOAD = new Type[] {
            typeof(Duality.Resources.Material), 
            typeof(Duality.Resources.Texture),
            typeof(Duality.Resources.Scene)
        };

        [NonSerialized]
        private Stack<IContentRef> _resourcesToLoad;

        [NonSerialized]
        private int _resourcesLoaded;

        [NonSerialized]
        private float? _deltaRect;


        void ICmpInitializable.OnInit(Component.InitContext context)
        {
            if(context == InitContext.Activate)
            {
                _resourcesToLoad = new Stack<IContentRef>();

                IEnumerable<IContentRef> resources = ContentProvider.GetAvailableContent(typeof(Resource));
                foreach (IContentRef cr in resources.Where(cr => !RESOURCES_TO_NOT_PRELOAD.Contains(cr.ResType)))
                {
                    _resourcesToLoad.Push(cr);
                }
            }
        }

        void ICmpInitializable.OnShutdown(Component.ShutdownContext context)
        {
            // nothing to do here
        }

        void ICmpUpdatable.OnUpdate()
        {
            // if it's still null means it's not initialized yet
            if (_resourcesToLoad != null)
            {
                if(_deltaRect == null)
                {
                    _deltaRect = this.GameObj.GetComponent<SpriteRenderer>().Rect.W / _resourcesToLoad.Count;
                    _resourcesLoaded = 0;
                }

                // fixing the loading bar's length
                Rect spriteRect = this.GameObj.GetComponent<SpriteRenderer>().Rect;
                spriteRect.W = _deltaRect.Value * _resourcesLoaded;
                this.GameObj.GetComponent<SpriteRenderer>().Rect = spriteRect;

                if (_resourcesToLoad.Count > 0)
                {
                    IContentRef contentRef = _resourcesToLoad.Pop();
                    if (!contentRef.IsLoaded)
                    {
                        Log.Game.Write("{0} > loading resource > {1}", DateTime.Now, contentRef.Name);
                        contentRef.MakeAvailable();
                    }
                    _resourcesLoaded++;
                }
                else
                {
                    Duality.Resources.Scene.SwitchTo(GameRes.Data.Scene_Scene);
                }
            }
        }
    }
}
