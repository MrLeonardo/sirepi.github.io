/*
 * A set of static helper classes that provide easy runtime access to the games resources.
 * This file is auto-generated. Any changes made to it are lost as soon as Duality decides
 * to regenerate it.
 */
namespace GameRes
{
	public static class Data {
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__10__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (10).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__11__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (11).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__12__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (12).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__13__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (13).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__14__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (14).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__15__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (15).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__16__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (16).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__17__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (17).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__18__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (18).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__19__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (19).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__2__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (2).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__20__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (20).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__21__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (21).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__22__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (22).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__23__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (23).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__24__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (24).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__25__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (25).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__26__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (26).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__27__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (27).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__28__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (28).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__29__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (29).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__3__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (3).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__30__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (30).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__4__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (4).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__5__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (5).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__6__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (6).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__7__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (7).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__8__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (8).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap__9__Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap (9).Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Material> _2048_pixmap_Material { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\2048_pixmap.Material.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> _2048_pixmap_Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\2048_pixmap.Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Texture> _2048_pixmap_Texture { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\2048_pixmap.Texture.res"); }}
		public static Duality.ContentRef<Duality.Resources.Scene> LoadingScene_Scene { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Scene>(@"Data\LoadingScene.Scene.res"); }}
		public static Duality.ContentRef<Duality.Resources.Scene> Scene_Scene { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Scene>(@"Data\Scene.Scene.res"); }}
		public static void LoadAll() {
			_2048_pixmap__10__Pixmap.MakeAvailable();
			_2048_pixmap__11__Pixmap.MakeAvailable();
			_2048_pixmap__12__Pixmap.MakeAvailable();
			_2048_pixmap__13__Pixmap.MakeAvailable();
			_2048_pixmap__14__Pixmap.MakeAvailable();
			_2048_pixmap__15__Pixmap.MakeAvailable();
			_2048_pixmap__16__Pixmap.MakeAvailable();
			_2048_pixmap__17__Pixmap.MakeAvailable();
			_2048_pixmap__18__Pixmap.MakeAvailable();
			_2048_pixmap__19__Pixmap.MakeAvailable();
			_2048_pixmap__2__Pixmap.MakeAvailable();
			_2048_pixmap__20__Pixmap.MakeAvailable();
			_2048_pixmap__21__Pixmap.MakeAvailable();
			_2048_pixmap__22__Pixmap.MakeAvailable();
			_2048_pixmap__23__Pixmap.MakeAvailable();
			_2048_pixmap__24__Pixmap.MakeAvailable();
			_2048_pixmap__25__Pixmap.MakeAvailable();
			_2048_pixmap__26__Pixmap.MakeAvailable();
			_2048_pixmap__27__Pixmap.MakeAvailable();
			_2048_pixmap__28__Pixmap.MakeAvailable();
			_2048_pixmap__29__Pixmap.MakeAvailable();
			_2048_pixmap__3__Pixmap.MakeAvailable();
			_2048_pixmap__30__Pixmap.MakeAvailable();
			_2048_pixmap__4__Pixmap.MakeAvailable();
			_2048_pixmap__5__Pixmap.MakeAvailable();
			_2048_pixmap__6__Pixmap.MakeAvailable();
			_2048_pixmap__7__Pixmap.MakeAvailable();
			_2048_pixmap__8__Pixmap.MakeAvailable();
			_2048_pixmap__9__Pixmap.MakeAvailable();
			_2048_pixmap_Material.MakeAvailable();
			_2048_pixmap_Pixmap.MakeAvailable();
			_2048_pixmap_Texture.MakeAvailable();
			LoadingScene_Scene.MakeAvailable();
			Scene_Scene.MakeAvailable();
		}
	}

}
