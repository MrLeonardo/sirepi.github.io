/*
 * A set of static helper classes that provide easy runtime access to the games resources.
 * This file is auto-generated. Any changes made to it are lost as soon as Duality decides
 * to regenerate it.
 */
namespace GameRes
{
	public static class Data {
		public static Duality.ContentRef<Duality.Resources.Material> Arrowhead_Top_Material { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\Arrowhead-Top.Material.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> Arrowhead_Top_Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\Arrowhead-Top.Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Texture> Arrowhead_Top_Texture { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\Arrowhead-Top.Texture.res"); }}
		public static Duality.ContentRef<Duality.Resources.Prefab> Bullet_Prefab { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Prefab>(@"Data\Bullet.Prefab.res"); }}
		public static Duality.ContentRef<Duality.Resources.Material> flash_Material { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\flash.Material.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> flash_Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\flash.Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Texture> flash_Texture { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\flash.Texture.res"); }}
		public static Duality.ContentRef<Duality.Resources.Scene> Scene_Scene { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Scene>(@"Data\Scene.Scene.res"); }}
		public static void LoadAll() {
			Arrowhead_Top_Material.MakeAvailable();
			Arrowhead_Top_Pixmap.MakeAvailable();
			Arrowhead_Top_Texture.MakeAvailable();
			Bullet_Prefab.MakeAvailable();
			flash_Material.MakeAvailable();
			flash_Pixmap.MakeAvailable();
			flash_Texture.MakeAvailable();
			Scene_Scene.MakeAvailable();
		}
	}

}
