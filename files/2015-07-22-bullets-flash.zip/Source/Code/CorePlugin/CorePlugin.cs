﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace Duality_
{
	/// <summary>
	/// Defines a Duality core plugin.
	/// </summary>
    public class Duality_CorePlugin : CorePlugin
    {
        public static readonly Random RND = new Random();
		// Override methods here for global logic
    }
}
