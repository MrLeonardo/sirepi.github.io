﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;
using OpenTK;
using Duality.Components;
using Duality.Components.Renderers;
using Duality.Components.Physics;

namespace Duality_
{
	[Serializable]
    [RequiredComponent(typeof(Transform))]
    [RequiredComponent(typeof(AnimSpriteRenderer))]
    public class PlayerComponent : Component, ICmpUpdatable
    {
        private static readonly int FLASH_TIMEOUT = 50;

        public int FireDelay { get; set; }

        private float _elapsedTime;
        private float _flashTime;
        private AnimSpriteRenderer _animSR;

        void ICmpUpdatable.OnUpdate()
        {
            // see how much time has past since the last frame..
            float lastDelta = Time.LastDelta * Time.TimeScale;
            _elapsedTime += lastDelta;
            _flashTime += lastDelta;

            if(_animSR == null)
            {
                _animSR = this.GameObj.GetComponent<AnimSpriteRenderer>();
            }

            // fix the mouse direction
            Transform t = this.GameObj.Transform;

            Vector3 mouseWorldPos = this.GameObj.ParentScene.FindComponent<Camera>().GetSpaceCoord(new Vector3(DualityApp.Mouse.Pos, t.Pos.Z));
            Vector2 direction = (mouseWorldPos - t.Pos).Xy;
            t.Angle = direction.Angle;

            if (_animSR.Active && _flashTime > FLASH_TIMEOUT)
            {
                _animSR.Active = false;
            }

            // shoot?
            if (DualityApp.Mouse.ButtonPressed(OpenTK.Input.MouseButton.Left))
            {
                if(_elapsedTime > FireDelay)
                {
                    // shoot!
                    GameObject bullet = GameRes.Data.Bullet_Prefab.Res.Instantiate();
                    bullet.BreakPrefabLink();
                    this.GameObj.ParentScene.AddObject(bullet);
                    bullet.GetComponent<Transform>().Pos = t.Pos;
                    bullet.GetComponent<Transform>().Angle = t.Angle;
                    bullet.GetComponent<RigidBody>().ApplyLocalImpulse(-Vector2.UnitY * 10);

                    _animSR.AnimFirstFrame = Duality_CorePlugin.RND.Next(_animSR.AnimFrameCount);
                    _animSR.Active = true;

                    // reset the counters
                    _elapsedTime = 0;
                    _flashTime = 0;
                }
            }

        }
    }
}
